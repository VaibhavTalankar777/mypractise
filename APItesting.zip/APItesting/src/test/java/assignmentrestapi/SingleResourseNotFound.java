package assignmentrestapi;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.when;

import org.testng.annotations.Test;

import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;

public class SingleResourseNotFound {

	@Test
	 public void singleUserNotFound()  {
		
		System.out.println("=========================THIS IS TEST 1 for singleUserNotFound=========================");
		
		baseURI="https://reqres.in/api";
		
		when()
		
	     .get("/unknown/23")
	     
		.then()
		
		    .statusCode(404)
		    .log().ifValidationFails(LogDetail.STATUS)
		    
		    .log().all();
		
	}
}
