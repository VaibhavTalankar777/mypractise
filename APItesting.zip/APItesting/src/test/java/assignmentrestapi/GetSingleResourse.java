package assignmentrestapi;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;

import io.restassured.filter.log.LogDetail;

public class GetSingleResourse {

	
	@Test
	public void valiadtesingleResourse()  {
		System.out.println("=========================THIS IS TEST 4 for Validate single Resourse =========================");
	baseURI ="https://reqres.in/api";
			
			given()
			.get("/unknown/2")
			
			.then()
			  .statusCode(200)
			  .log().ifValidationFails(LogDetail.STATUS)
			  .body("data.name", equalTo("fuchsia rose"))
			  .body("data.color", equalTo("#C74375"))
			  .log().body();
			
		}
}
