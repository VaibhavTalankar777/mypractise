package assignmentrestapi;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;

public class LoginSucessful {

@Test
public void testLoginSucess()  {
	System.out.println("=========================THIS IS TEST 7 for test Login Success=========================");
	
	baseURI="https://reqres.in/api";
	
	JSONObject reqData=  new JSONObject();
	
	reqData.put("email", "eve.holt@reqres.in");
	reqData.put("password", "cityslick");
	
	System.out.println(reqData.toJSONString());
	
	given()
	
	.header("Content-Type","application/json")
	.header("Connection","keep-alive")
//	.contentType(ContentType.JSON)
	.accept(ContentType.JSON)
	.body(reqData.toJSONString())
	
	.when()
	     .post("/login")
	.then()
	     .statusCode(200)
	     .log().ifValidationFails(LogDetail.STATUS)
	     
	     .log().all();    //It will log all response body
	
} 
}

