package assignmentrestapi;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasItems;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.response.Response;

public class GetListResourses {

	@Test(priority=1)
	public void valiadteListResourses()  {
		
		System.out.println("=========================THIS IS TEST 2 for GetListResourses=========================");
	baseURI ="https://reqres.in/api";
			
			given()
			.get("/unknown")
			
			.then()
			  .statusCode(200)
			  .log().ifValidationFails(LogDetail.STATUS)
			  .log().all();
			
		}

	@Test(priority=2)
	public void testValidateGetListResourseslistData()  {
		System.out.println("=========================THIS IS TEST 3 for Validate GetListResourseslistData=========================");
        baseURI ="https://reqres.in/api";
		
		given()
		.get("/unknown")
		
		.then()
		  .statusCode(200)
		  .body("data[2].id",equalTo(3))
		  .body("data[0].name",equalTo("cerulean"))
		  .body("data.name",hasItem("fuchsia rose"))
		  .body("data.name",hasItems("cerulean","fuchsia rose","true red"))
  		  .log().body()          //for response  body printing
	      .log().headers()
//		  .log().everything()
     	  .log().status()
		  .log().ifStatusCodeIsEqualTo(203)
		  .log().ifValidationFails(LogDetail.STATUS);
//		  .log().all();
}
}