package restassuredtestcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetSingleUser {
	@Test
	void TestGetsingleUserList() {
		System.out.println("===========================This is test 1 ============================");
		Response rsp= RestAssured.get("https://reqres.in/api/users/2");
		
		System.out.println(rsp.getStatusCode());
		Assert.assertEquals(rsp.getStatusCode(), 200);
		
		//getting response body
		System.out.println(rsp.getBody().asString());
		System.out.println("The response body is - \n " + rsp.body().asString());
		
		//response time
		System.out.println("The response time in milliseconds is "+rsp.getTime());
	
	
	//Get Header 
		System.out.println("Content type header is - \n "+rsp.header("content-type"));
		//this method can be used to get specific type of header
		
		System.out.println("Response headers are - \n" + rsp.headers());
		//this method can be used to get all the  response headers
	}

	
	@Test
	void TestGetsingleUserDetails() {
		
		System.out.println("===========================This is test 2 ============================");
		String userid ="2";
		Response rsp= RestAssured.get("https://reqres.in/api/users/"  +userid );
		
		System.out.println(rsp.getStatusCode());
		Assert.assertEquals(rsp.getStatusCode(), 200);
		
		//getting response body
		System.out.println(rsp.getBody().asString());
		System.out.println("The response body is - \n " + rsp.body().asString());
		
		//response time
		System.out.println("The response time in milliseconds is "+rsp.getTime());
	
	
	//Get Header 
		System.out.println("Content type header is - \n "+rsp.header("content-type"));
		//this method can be used to get specific type of header
		
		System.out.println("Response headers are - \n" + rsp.headers());
		//this method can be used to get all the  response headers
	}

}
